package com.javacodegeeks.foodcalorieintake;

import static android.os.Build.ID;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper
{
    public static final String DATABASE_NAME = "mealtime.db";
    public static final String TABLE_NAME = "MEALTIME";

    //Columns
    public static final String COL_1 = "id";
    public static final String COL_2 = "username";
    public static final String COL_3 = "foodid";
    public static final String COL_4 = "date";
    public static final String COL_5 = "quantity";
    public static final String COL_6 = "calorie";

    public DatabaseHelper(Context context)
    {
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE " +TABLE_NAME+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, USERNAME TEXT, FOODID TEXT, DATE TEXT, QUANTITY TEXT, CALORIE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " +TABLE_NAME);
        onCreate(db);
    }
    public Cursor getData()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query,null);
        return data;
    }

    public boolean insertData(String username, String foodid, String date, String quant, String cal)
    {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,username);
        contentValues.put(COL_3,foodid);
        contentValues.put(COL_4,date);
        contentValues.put(COL_5,quant);
        contentValues.put(COL_6,cal);

        long result =db.insert(TABLE_NAME,null,contentValues);

        if (result== -1)
            return false;
        else
            return true;
    }

    public List<ReportModelClass> getReportList(String uname,String d){
        String sql = "select * from "+ TABLE_NAME +"WHERE ";
        SQLiteDatabase db = this.getReadableDatabase();
        List<ReportModelClass> storeReport = new ArrayList<>();
        Cursor c = db.rawQuery("select * from "+TABLE_NAME+" WHERE username = ? AND date = ?", new String[]{uname,d});
        if (c.moveToFirst()){
            do {
                int id = Integer.parseInt(c.getString(0));
                String username = c.getString(1);
                String fid = c.getString(2);
                String ddate = c.getString(3);
                String quanti = c.getString(4);
                String calo = c.getString(5);

                storeReport.add(new ReportModelClass(id,username,fid,ddate,quanti,calo));
            }while(c.moveToNext());
        }
        c.close();
        return storeReport;

    }

    public void deleteReport(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "id= ?", new String[]{String.valueOf(id)});
    }

    public Double getTotal(String uname,String d){
        Double total=0.0;
        SQLiteDatabase db = this.getReadableDatabase();
        List<ReportModelClass> storeReport = new ArrayList<>();
        Cursor c = db.rawQuery("select * from "+TABLE_NAME+" WHERE username = ? AND date = ?", new String[]{uname,d});
        if (c.moveToFirst()){
            do {

                String calo = c.getString(5);

                try{
                    Double i = Double.parseDouble(calo);
                    total += i;
                } catch(NumberFormatException ex){
                }


            }while(c.moveToNext());
        }
        c.close();
        return total;
    }

    /*public String getName(String username, String password)
    {
        SQLiteDatabase mydb = this.getReadableDatabase();
        Cursor cursor = mydb.rawQuery("select * from user where username=? and password=?", new String[] {username,password});

        if(cursor.getCount()>0)
        {
            return true;
        }
        else {
            return false;
        }

    }

    public String getID(String username, String password)
    {
        SQLiteDatabase mydb = this.getReadableDatabase();
        Cursor cursor = mydb.rawQuery("select * from user where username=? and password=?", new String[] {username,password});

        if(cursor.getCount()>0)
        {
            return true;
        }
        else {
            return false;
        }

    }
*/

}
