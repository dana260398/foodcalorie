package com.javacodegeeks.foodcalorieintake;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Report extends AppCompatActivity {

    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";

    // key for storing email.
    public static final String USERNAME_KEY = "username_key";

    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";

    //Initialize variable
    DrawerLayout drawerLayout;

    private TextView pick;
    private TextView calN;
    private TextView calT;
    private TextView dates;
    private DatePickerDialog.OnDateSetListener dateSetListener;

    // variable for shared preferences.
    SharedPreferences sharedpreferences;
    String username;
    DatabaseHelper db;
    DBHelper database;
    String date;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        //assign variable
        drawerLayout = findViewById(R.id.drawer_layout);

        SessionManagement sessionManagement = new SessionManagement(this);
        String name=sessionManagement.getUsername();
        database = new DBHelper(this);


        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        username = sharedpreferences.getString(USERNAME_KEY, null);
        btn =findViewById(R.id.button);
        pick = findViewById(R.id.pickdate);
        calN = findViewById(R.id.calorieneed);
        calT = findViewById(R.id.calorietaken);
        dates = findViewById(R.id.datee);

        Integer calo=0;
        Double calor=0.0;
        calo =database.getCalorie(username);
        calor=Double.parseDouble(String.valueOf(calo));
        calN.setText(calor.toString());

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        String currentDate = sdf.format(new Date());
        Double totalCalo =0.0;
        totalCalo=totalCal(username,currentDate);

        dates.setText(currentDate);
        calT.setText(totalCalo.toString());




        //pick date
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog  =new DatePickerDialog(Report.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,dateSetListener, year,month,day);

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                dialog.show();

            }
        });
        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month+1;
                if(month<10)
                {
                    date = day + ".0" + month + "."+ year;
                }
                else if (month>=10)
                {
                    date = day + "." + month + "."+ year;
                }


                db = new DatabaseHelper(Report.this);
                pick.setText(date);


            }
        };
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String d = pick.getText().toString();
                Intent intent = new Intent(Report.this, ViewReport.class);
                intent.putExtra("date", d);
                startActivity(intent);
            }
        });
    }

    public Double totalCal(String username,String date){
        Double total=0.0;
        db = new DatabaseHelper(this);
        total=db.getTotal(username,date);
        return total;

    }


    public void ClickMenu(View view){
        //open drawer
        mainNav.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        mainNav.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view){
        //Redirect activity to home
        mainNav.redirectActivity(this,mainNav.class);

    }
    public void ClickMeal(View view){
        //redirect activity to meal time
        mainNav.redirectActivity(this,Mealtime.class);

    }

    public void ClickFood(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Food.class);


    }
    public void ClickReport(View view){
        //Redirect activity to food
        recreate();

    }
    public void ClickSetting(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Setting.class);

    }
    public void ClickLogout(View view){
        //Redirect activity to food
        mainNav.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        mainNav.closeDrawer(drawerLayout);
    }
}