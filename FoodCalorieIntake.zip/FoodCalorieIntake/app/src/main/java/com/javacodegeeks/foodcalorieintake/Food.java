package com.javacodegeeks.foodcalorieintake;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mancj.materialsearchbar.MaterialSearchBar;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class Food extends AppCompatActivity{
    //Initialize variable
    DrawerLayout drawerLayout;
    //RecyclerView recyclerView;
    //RecyclerView.LayoutManager layoutManager;
    //SearchAdapter adapter;

    TextView lst;

    SearchView searchView;
    ArrayAdapter <String> adapter;
    ListView listView;
    TextView textView;
    //MaterialSearchBar materialSearchBar;
    ArrayList listItem = new ArrayList();
    ArrayList <String> name;
    DBAccess dbAccess;

    public static ArrayList <FoodModel> listFood = new ArrayList<>();
    DBAccess database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        //assign varible
        drawerLayout = findViewById(R.id.drawer_layout);
       // textView = findViewById(R.id.text_food);
        listView = findViewById(R.id.list_view_food);





        dbAccess = new DBAccess(this,null,null,1);
        listItem.add(dbAccess.loadHandler());
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listItem);

        listView.setAdapter(adapter);

        /*textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //EditText editText = findViewById(R.id.edit_text_food);



                editText.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        adapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        textView.setText(adapter.getItem(i));
                    }
                });
            }
        });*/


        //init View
        /*recyclerView = (RecyclerView) findViewById(R.id.recycler_search);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);*/

        //materialSearchBar = (MaterialSearchBar) findViewById(R.id.search_bar);

        //init DB

       // DBAccess dbAccess = new DBAccess(this,null,null,1);

        //listItem.add(dbAccess.loadHandler());
        //name.add(dbAccess.loadName());

        //adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listItem);
       // listfood.setAdapter(adapter);

        //search

        /*searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //String lower = query.toLowerCase();

                if(query.contains(listItem.toString())){
                    adapter.getFilter().filter(query);
                }else{
                    Toast.makeText(Food.this, "No Match found",Toast.LENGTH_LONG).show();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //adapter.getFilter().filter(newText);
                return false;
            }
        });
*/

        // viewData();
        /*
        //setup search bar
        materialSearchBar.setHint("Search");
        materialSearchBar.setCardViewElevation(10);
        loadSuggestion();
        materialSearchBar.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                List <String> suggest = new ArrayList<>();
                for (String search:suggestList){
                    if (search.toLowerCase().contains(materialSearchBar.getText().toLowerCase()))
                        suggest.add(search);
                }
                materialSearchBar.setLastSuggestions(suggest);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        materialSearchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {
                if(!enabled)
                    recyclerView.setAdapter(adapter);
            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                startSearch(text.toString());
            }

            @Override
            public void onButtonClicked(int buttonCode) {

            }
        });

        adapter =new SearchAdapter(this,database.getFood());
        recyclerView.setAdapter(adapter);*/


    }



   /* @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {


        // Initialise menu item search bar
        // with id and take its object
        MenuItem searchViewItem = menu.findItem(R.id.search_bar);
        SearchView searchView = (SearchView) searchViewItem.getActionView();

        // attach setOnQueryTextListener
        // to search view defined above
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }*/

   /*private void initSearchWidgets(){
        SearchView searchView= (SearchView) findViewById(R.id.searchlist);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                ArrayList <FoodModel> filterfood = new ArrayList<FoodModel>();
                for (FoodModel food:listFood)
                {
                    if (food.getName().toLowerCase().contains(s.toLowerCase()))
                    {
                        filterfood.add(food);
                    }
                }
                FoodAdapter adapter = new FoodAdapter();

                return false;
            }
        });
    }*/

   /* private void viewData() {
        Cursor cursor =database.viewData();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No data to show", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                listItem.add(cursor.getString(1));
            }
            adapter = new ArrayAdapter(this, android.R.layout.activity_list_item,listItem);
        }
    }*/

   /* private void startSearch(String text) {
        adapter = new SearchAdapter(this,database.getFoodByName(text));
        recyclerView.setAdapter(adapter);
    }

    private void loadSuggestion() {
        suggestList = database.getNames();
        materialSearchBar.setLastSuggestions(suggestList);
    }
*/

    public void ClickMenu(View view){
        //open drawer
        mainNav.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        mainNav.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view){
        //Redirect activity to home
        mainNav.redirectActivity(this,mainNav.class);

    }
    public void ClickMeal(View view){
        //redirect activity to meal time
        mainNav.redirectActivity(this,Mealtime.class);

    }

    public void ClickFood(View view){
        //Redirect activity to food
        recreate();

    }
    public void ClickReport(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Report.class);

    }
    public void ClickSetting(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Setting.class);

    }
    public void ClickLogout(View view){
        //Redirect activity to food
        mainNav.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        mainNav.closeDrawer(drawerLayout);
    }


}