package com.javacodegeeks.foodcalorieintake;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME= "trackcalapp.db";
    private static final int DATABASE_VERSION =1;

    public DBHelper(Context context) {

        super(context, DBNAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table user(username TEXT primary key,password TEXT, age INTEGER, gender TEXT, registerdate TEXT, weight REAL,height REAL, bmistatus TEXT, paintensity TEXT, caloriesneed INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists user");

    }

    public Boolean registeruser(String username, String password, Integer age, String gender, String date, Double weight, Double height, String bmistatus,String intensity, Double calories){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("age",age);
        contentValues.put("gender",gender);
        contentValues.put("registerdate",date);
        contentValues.put("weight",weight);
        contentValues.put("height",height);
        contentValues.put("bmistatus",bmistatus);
        contentValues.put("paintensity",intensity);
        contentValues.put("caloriesneed",calories);

        long result =db.insert("user",null,contentValues);

        if (result== -1)
            return false;
        else
            return true;

    }

    public Boolean settingUpdate(String username,String pass){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("password",pass);

        long result =db.update("user",contentValues,"username = ?", new String[]{username});

        if (result== -1)
            return false;
        else
            return true;

    }

    public Boolean profileUpdate(String username,Double weight, Double height, String stat, String intense,Double cal ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("weight",weight);
        contentValues.put("height",height);
        contentValues.put("bmistatus",stat);
        contentValues.put("paintensity",intense);
        contentValues.put("caloriesneed",cal);

        long result =db.update("user",contentValues,"username = ?", new String[]{username});

        if (result== -1)
            return false;
        else
            return true;

    }

    public String getPassword(String username){
        String temp="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getString(1);

        }
        c.close();
        db.close();
        return temp;
    }

    public Boolean checkuser(String username, String password)
    {
        SQLiteDatabase mydb = this.getReadableDatabase();
        Cursor cursor = mydb.rawQuery("select * from user where username=? and password=?", new String[] {username,password});

        if(cursor.getCount()>0)
            {
               return true;
            }
            else {
                return false;
            }

    }

    public Integer getCalorie(String username){
        Integer cal=0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            cal = c.getInt(9);

        }
        c.close();
        db.close();
        return cal;
    }

    public Integer getAge(String username){
       Integer temp=0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getInt(2);

        }
        c.close();
        db.close();
        return temp;
    }

    public String getGender(String username){
        String temp="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getString(3);

        }
        c.close();
        db.close();
        return temp;
    }
    public Double getWeight(String username){
        Double temp=0.0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getDouble(5);

        }
        c.close();
        db.close();
        return temp;
    }

    public Double getHeight(String username){
        Double temp=0.0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getDouble(6);

        }
        c.close();
        db.close();
        return temp;
    }
    public String getStatus(String username){
        String temp="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getString(7);

        }
        c.close();
        db.close();
        return temp;
    }
    public String getIntense(String username){
        String temp="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from user where username=? ", new String[] {username});

        while (c.moveToNext()){


            temp = c.getString(8);

        }
        c.close();
        db.close();
        return temp;
    }
}
