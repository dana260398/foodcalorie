package com.javacodegeeks.foodcalorieintake;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

class SearchViewHolder extends RecyclerView.ViewHolder{

    public TextView name,size,weight,calorie;

    public SearchViewHolder(View itemView){
        super(itemView);
        name = (TextView) itemView.findViewById(R.id.name);
        size = (TextView) itemView.findViewById(R.id.size);
        weight = (TextView) itemView.findViewById(R.id.weight);
        calorie = (TextView) itemView.findViewById(R.id.calorie);

    }
}

public class SearchAdapter extends RecyclerView.Adapter<SearchViewHolder>{

    private Context context;
    private List<FoodModel> food;

    public SearchAdapter(Context context, List<FoodModel> food) {
        this.context = context;
        this.food = food;
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.activity_food, parent,false);

        return new SearchViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, int position) {
        holder.name.setText(food.get(position).getName());
        holder.size.setText(food.get(position).getSize());
        holder.weight.setText(food.get(position).getWeight());
        holder.calorie.setText(food.get(position).getCalories());
    }

    @Override
    public int getItemCount() {
        return food.size();
    }
}
