package com.javacodegeeks.foodcalorieintake;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Mealtime extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    //Initialize variable
    DrawerLayout drawerLayout;
    TextView textView;
    EditText date;
    Spinner spinner;
    ArrayList<String> arrayList;
    ArrayAdapter <String> adapter;
    Dialog dialog;
    ArrayList <String> listItem = new ArrayList<>();
    String choose;
    DBAccess dbAccess;
    Button insertbutton, reportbutton;
    Double q=0.0;
    DatabaseHelper DB;
    DBHelper database;


    Double [] quantity = {0.5,1.0,1.5,2.0,2.5,3.0,3.5,4.0,4.5,5.0,5.5,6.0,6.5,7.0,7.5,8.0,8.5,9.0,9.5,10.0};
    Double calories;

    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";

    // key for storing email.
    public static final String USERNAME_KEY = "username_key";

    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";

    SharedPreferences sharedpreferences;
    String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mealtime);

        //assign varible
        drawerLayout = findViewById(R.id.drawer_layout);
        textView=findViewById(R.id.food);
        insertbutton = findViewById(R.id.button_first);
        reportbutton = findViewById(R.id.button_second);


        SessionManagement sessionManagement = new SessionManagement(this);
        String name=sessionManagement.getUsername();


        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        username = sharedpreferences.getString(USERNAME_KEY, null);


        //notification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("My Notification", "My Notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        DB = new DatabaseHelper(this);

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        String currentDate = sdf.format(new Date());

        date = findViewById(R.id.date);
        date.setText(currentDate);

        Spinner quan = findViewById(R.id.quantity);
        quan.setOnItemSelectedListener(this);

        ArrayAdapter ad
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                quantity);

        // set simple layout resource file
        // for each item of spinner
        ad.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);

        // Set the ArrayAdapter (ad) data on the
        // Spinner which binds data to spinner

        quan.setAdapter(ad);


        arrayList = new ArrayList<>();
        dbAccess = new DBAccess(this,null,null,1);
        List<String> labels = dbAccess.getAllLabels();


        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    dialog= new Dialog(Mealtime.this);

                   dialog.setContentView(R.layout.dialog_searchable_spinner);

                   dialog.getWindow().setLayout(750,900);

                   dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

                   dialog.show();

                   EditText editText = dialog.findViewById(R.id.edit_text);
                ListView listView = dialog.findViewById(R.id.list_view);

                adapter = new ArrayAdapter(Mealtime.this, android.R.layout.simple_list_item_1,labels);

                listView.setAdapter(adapter);

                editText.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        adapter.getFilter().filter(charSequence);
                    }

                    @Override
                    public void afterTextChanged(Editable editable) {

                    }
                });

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        textView.setText(adapter.getItem(i));
                        choose = adapter.getItem(i).toString();
                        String detail = dbAccess.getDetail(choose);

                        Toast.makeText(getApplicationContext(), detail, Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                });
            }
        });

        reportbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Mealtime.this, Report.class);
                startActivity(intent);
            }
        });

        insertbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String indate ;
                indate = date.getText().toString();
                String infood = choose;
                Double quantity = q;
                Double calorie=0.0;
                Double totalcal=0.0;

                Integer id = dbAccess.getID(infood);
                Integer cal = dbAccess.getCalorie(infood);

                calorie = q * cal;
                totalcal += calorie;
                String totalCalorie = totalcal.toString();

                String kalori = calorie.toString();
               // db = openHelper.getWritableDatabase();
                //insertData(date,food,quantity);
                Boolean check  = DB.insertData(username,id.toString(),indate,quantity.toString(),kalori);
                database = new DBHelper(Mealtime.this);
                Integer calo=0;
                Double calor=0.0;
                calo =database.getCalorie(username);
                calor=Double.parseDouble(String.valueOf(calo));


                Double totalCalo =0.0;
                totalCalo=totalCal(username,currentDate);

                if (check==true){
                    Double result=0.0;
                    if (totalCalo>calor)
                    {
                        NotificationCompat.Builder builder = new NotificationCompat.Builder(Mealtime.this,"My Notification");
                        builder.setContentTitle("Calories Taken Exceeded!");
                        builder.setContentText("You already take more than your calories needed!");
                        builder.setSmallIcon(R.drawable.ic_food);
                        builder.setAutoCancel(true);

                        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(Mealtime.this);
                        managerCompat.notify(1,builder.build());
                    }else{}
                    Toast.makeText(Mealtime.this, "Succesfully Insert",Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(Mealtime.this, "Unsuccesfully",Toast.LENGTH_SHORT).show();

            }
        });



    }
    public Double totalCal(String username,String date){
        Double total=0.0;
        DB = new DatabaseHelper(this);
        total=DB.getTotal(username,date);
        return total;

    }

    private void loadSpinnerData() {
        DBAccess dbAccess = new DBAccess(getApplicationContext());
        List<String> labels = dbAccess.getAllLabels();

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, labels);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position,
                               long id) {
        // On selecting a spinner item
        String label = parent.getItemAtPosition(position).toString();
        q = Double.parseDouble(label);

        // Showing selected spinner item
       //Toast.makeText(parent.getContext(), "You selected: " + label,
                //Toast.LENGTH_LONG).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    public void ClickMenu(View view){
        //open drawer
        mainNav.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        mainNav.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view){
        //Redirect activity to home
        mainNav.redirectActivity(this,mainNav.class);
        finish();
    }
    public void ClickMeal(View view){
        //redirect activity to meal time
        recreate();

    }

    public void ClickFood(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Food.class);
        finish();
    }
    public void ClickReport(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Report.class);
        finish();
    }
    public void ClickSetting(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Setting.class);
        finish();
    }
    public void ClickLogout(View view){
        //Redirect activity to food
        mainNav.logout(this);

    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        mainNav.closeDrawer(drawerLayout);
    }


}