package com.javacodegeeks.foodcalorieintake;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Setting extends AppCompatActivity {

    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";

    // key for storing email.
    public static final String USERNAME_KEY = "username_key";

    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";

    //Initialize variable
    DrawerLayout drawerLayout;
    Button update;
    EditText current, newpass, confirm;
    DBHelper db;
    // variable for shared preferences.
    SharedPreferences sharedpreferences;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        //assign varible
        drawerLayout = findViewById(R.id.drawer_layout);

        SessionManagement sessionManagement = new SessionManagement(this);
        String name=sessionManagement.getUsername();

        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        username = sharedpreferences.getString(USERNAME_KEY, null);

        update = findViewById(R.id.update);
        current = findViewById(R.id.current);
        newpass = findViewById(R.id.newpass);
        confirm = findViewById(R.id.conf);

        db = new DBHelper(this);


        String currentPass = "";
        currentPass = db.getPassword(username);
        current.setText(currentPass.toString());

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pass = newpass.getText().toString();
                String confpassword = confirm.getText().toString();


                Boolean checkpassword = checkPass(pass,confpassword);
                if(checkpassword == false){
                    Toast.makeText(Setting.this, "Password Not matching",Toast.LENGTH_SHORT).show();
                }
                else{


                    boolean settingUpdate=db.settingUpdate(username,pass);

                    if (settingUpdate ==true){
                        Toast.makeText(Setting.this, "Succesfully Updated",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Setting.this, Setting.class);
                        startActivity(intent);
                    }
                    else
                        Toast.makeText(Setting.this, "Unsuccesfully",Toast.LENGTH_SHORT).show();




                }
            }
        });





    }

    private Boolean checkPass(String password, String confpassword) {
        Boolean temp = true;
        if(!password.equals(confpassword)){

            temp=false;
        }

        return temp;
    }

    public void ClickMenu(View view){
        //open drawer
        mainNav.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        mainNav.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view){
        //Redirect activity to home
        mainNav.redirectActivity(this,mainNav.class);

    }
    public void ClickMeal(View view){
        //redirect activity to meal time
        mainNav.redirectActivity(this,Mealtime.class);

    }

    public void ClickFood(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Food.class);


    }
    public void ClickReport(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Report.class);

    }
    public void ClickSetting(View view){
        //Redirect activity to food
        recreate();


    }
    public void ClickLogout(View view){
        //Redirect activity to food
        mainNav.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        mainNav.closeDrawer(drawerLayout);
    }
}