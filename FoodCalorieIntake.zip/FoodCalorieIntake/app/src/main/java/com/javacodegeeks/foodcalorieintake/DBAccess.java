package com.javacodegeeks.foodcalorieintake;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.Build;


import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class DBAccess extends SQLiteOpenHelper {
    private static String DB_PATH="/data/data/com.javacodegeeks.foodcalorieintake/databases/";
    private static String DB_NAME="food.db";
    private static final String TABLE_NAME = "labels";
    public static final int DB_VERSION=1;
    private SQLiteDatabase mDatabase;
    private Context mContext=null;

    public DBAccess(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DB_NAME, factory, DB_VERSION);
        this.mContext =context;

    }

    public DBAccess(Context context) {
        super(context, DB_NAME, null, DB_VERSION);


    }



  /*@SuppressLint("Range")
   public List <FoodModel> getFood(){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSqlect = {"foodid","name","servingsize","servingweight","calories"};
        String tableName="food";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlSqlect,null,null,null,null,null);
        List<FoodModel> result = new ArrayList<>();
        if (cursor.moveToFirst())
        {
            do {
                FoodModel food = new FoodModel();
                food.setId(cursor.getInt(cursor.getColumnIndex("foodid")));
                food.setName(cursor.getString(cursor.getColumnIndex("name")));
                food.setSize(cursor.getString(cursor.getColumnIndex("servingsize")));
                food.setWeight(cursor.getString(cursor.getColumnIndex("servingweight")));
                food.setCalories(cursor.getInt(cursor.getColumnIndex("calories")));
                result.add(food);
            }
            while (cursor.moveToNext());
        }
        return result;
    }

    @SuppressLint("Range")
    public List<String> getNames() {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSqlect = {"name"};
        String tableName="food";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlSqlect,null,null,null,null,null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst())
        {
            do {

                result.add(cursor.getString(cursor.getColumnIndex("name")));
            }
            while (cursor.moveToNext());
        }
        return result;
    }

    @SuppressLint("Range")
    public List<FoodModel> getFoodByName(String name){
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlSqlect = {"foodid","name","servingsize","servingweight","calories"};
        String tableName="food";

        qb.setTables(tableName);


        Cursor cursor = qb.query(db,sqlSqlect,"name LIKE ?",new String[]{"%"+name+"%"},null,null,null);
        List<FoodModel> result = new ArrayList<>();
        if (cursor.moveToFirst())
        {
            do {
                FoodModel food = new FoodModel();
                food.setId(cursor.getInt(cursor.getColumnIndex("foodid")));
                food.setName(cursor.getString(cursor.getColumnIndex("name")));
                food.setSize(cursor.getString(cursor.getColumnIndex("servingsize")));
                food.setWeight(cursor.getString(cursor.getColumnIndex("servingweight")));
                food.setCalories(cursor.getInt(cursor.getColumnIndex("calories")));
                result.add(food);
            }
            while (cursor.moveToNext());
        }
        return result;
    }









*/

   public String loadHandler(){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        String result = "";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food", null);

        while (c.moveToNext()){

            String result_name = c.getString(1);
            String result_serving = c.getString(2);
            String result_weight = c.getString(3);
            String result_calorie = c.getString(4);
            result += String.valueOf(result_name) + System.getProperty("line.separator") + result_serving+ System.getProperty("line.separator");
            result += String.valueOf(result_weight) + System.getProperty("line.separator")+ result_calorie+ " calories" +System.getProperty("line.separator")+System.getProperty("line.separator");
        }
        c.close();
        db.close();
        return result;
    }

    public String loadName(){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        String result = "";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food", null);

        while (c.moveToNext()){

            String result_name = c.getString(1);
            result += String.valueOf(result_name) ;
        }
        c.close();
        db.close();
        return result;
    }

    public Integer getID(String name){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        Integer result_id=0;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food WHERE name = ?", new String[]{String.valueOf(name)});

        while (c.moveToNext()){

            result_id = c.getInt(0);

        }
        c.close();
        db.close();
        return result_id;
    }

    public Integer getCalorie(String name){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        Integer result_calorie =0;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food WHERE name = ?",new String[]{String.valueOf(name)});

        while (c.moveToNext()){

            result_calorie = c.getInt(4);

        }
        c.close();
        db.close();
        return result_calorie;
    }

    public String getDetail(String name){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        String result="";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food WHERE name = ?", new String[]{String.valueOf(name)});

        while (c.moveToNext()){


            String result_serving = c.getString(2);
            String result_weight = c.getString(3);
            String result_calorie = c.getString(4);
            result +=  result_serving+ System.getProperty("line.separator");
            result += String.valueOf(result_weight) + System.getProperty("line.separator")+ result_calorie+ " calories";
        }
        c.close();
        db.close();
        return result;
    }
    public String getName(String id){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        String result_name="";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food WHERE foodid = ?", new String[]{String.valueOf(id)});

        while (c.moveToNext()){


           result_name = c.getString(1);

        }
        c.close();
        db.close();
        return result_name;
    }

    //method view data
   /* public String viewData(){
        try {
            createDatabase();
        }catch (IOException e){
            e.printStackTrace();
        }
        String result = "";
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("select * from food", null);

        while (c.moveToNext()){
            int result_id = c.getInt(0);
            String result_name = c.getString(1);
            result += String.valueOf(result_id) + " "+ result_name+ System.getProperty("line.separator");
        }
        c.close();
        db.close();
        return result;
    }*/
    public void createDatabase() throws IOException{
        boolean mDatabaseExist = checkDatabase();
        if(!mDatabaseExist){
            this.getReadableDatabase();
            this.close();
            try {
                copyDatabase();
            }
            catch (IOException mIOException){
                mIOException.printStackTrace();
                throw new Error("Error copying Database");

            }finally {
                this.close();
            }
        }
    }
    private boolean checkDatabase(){
        try {
            final String mPath = DB_PATH+DB_NAME;
            final File file = new File(mPath);
            if (file.exists())
                return true;
            else
                return false;
        }
        catch (SQLException e){
            e.printStackTrace();
            return false;
        }

    }
    private void copyDatabase() throws IOException{
        try {
            InputStream mInputStream = mContext.getAssets().open(DB_NAME);
            String outFileName = DB_PATH + DB_NAME;
            OutputStream mOutputStream = new FileOutputStream(outFileName);

            byte[] buffer =new byte[1024];
            int length;
            while ((length = mInputStream.read(buffer)) >0){
                mOutputStream.write(buffer,0,length);
            }
            mOutputStream.flush();
            mOutputStream.close();
            mInputStream.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public synchronized void close() {
        if (mDatabase !=null)
            mDatabase.close();
        SQLiteDatabase.releaseMemory();
        super.close();
    }

    public void openDatabase(){
        String path = DB_PATH+DB_NAME;
        mDatabase = SQLiteDatabase.openDatabase(path,null,SQLiteDatabase.OPEN_READWRITE);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS food");

        onCreate(sqLiteDatabase);
    }

    public List<String> getAllLabels() {
        List<String> list = new ArrayList<String>();



        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from food", null);//selectQuery,selectedArguments

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                list.add(cursor.getString(1));//adding 2nd column data
            } while (cursor.moveToNext());
        }
        // closing connection
        cursor.close();
        db.close();
        // returning lables
        return list;

    }

    public List getAllInfo() {
        List list = new ArrayList();



        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from food", null);//selectQuery,selectedArguments

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                list.add(cursor.getString(1) );

            } while (cursor.moveToNext());
        }
        // closing connection
        cursor.close();
        db.close();
        // returning lables
        return list;

    }
}
