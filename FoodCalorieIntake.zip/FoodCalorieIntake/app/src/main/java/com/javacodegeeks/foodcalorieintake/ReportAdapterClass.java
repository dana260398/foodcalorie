package com.javacodegeeks.foodcalorieintake;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReportAdapterClass extends RecyclerView.Adapter<ReportAdapterClass.ViewHolder> {

   List<ReportModelClass> report;
   Context context;
   DatabaseHelper databaseHelper;

    public ReportAdapterClass(List<ReportModelClass> report, Context context) {
        this.report = report;
        this.context = context;
        databaseHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.report_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final ReportModelClass reportModelClass = report.get(position);
        int pos = position;

        DBAccess dbAccess = new DBAccess(context);
        String name = dbAccess.getName(reportModelClass.getFoodid().toString());

        holder.textViewDate.setText(reportModelClass.getDate());
        holder.textViewName.setText("Name: "+name);
        holder.textViewQuantity.setText("Quantity: "+reportModelClass.getQuantity());
        holder.textViewCalo.setText(reportModelClass.getCalorie() + " calories");

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseHelper.deleteReport(reportModelClass.getId());
                report.remove(pos);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return report.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDate;
        TextView textViewName;
        TextView textViewQuantity;
        TextView textViewCalo;
        Button delete;
        public ViewHolder(@NonNull View itemView){
            super(itemView);

            textViewDate = itemView.findViewById(R.id.date);
            textViewName = itemView.findViewById(R.id.name);
            textViewQuantity = itemView.findViewById(R.id.quantity);
            textViewCalo = itemView.findViewById(R.id.calorie);
            delete = itemView.findViewById(R.id.delete);



        }
    }

}
