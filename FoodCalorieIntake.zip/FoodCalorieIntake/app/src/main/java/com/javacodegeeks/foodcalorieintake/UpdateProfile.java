package com.javacodegeeks.foodcalorieintake;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class UpdateProfile extends AppCompatActivity {
    // creating constant keys for shared preferences.
    public static final String SHARED_PREFS = "shared_prefs";

    // key for storing email.
    public static final String USERNAME_KEY = "username_key";

    // key for storing password.
    public static final String PASSWORD_KEY = "password_key";


    DrawerLayout drawerLayout;
    // variable for shared preferences.
    SharedPreferences sharedpreferences;
    String username;
    String bmiStatus;
    Spinner type;
    DBHelper db;
    EditText weight,height;
    Button update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        //assign varible
        drawerLayout = findViewById(R.id.drawer_layout);

        //assign varible
        drawerLayout = findViewById(R.id.drawer_layout);

        SessionManagement sessionManagement = new SessionManagement(this);
        String name=sessionManagement.getUsername();

        // initializing our shared preferences.
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);

        // getting data from shared prefs and
        // storing it in our string variable.
        username = sharedpreferences.getString(USERNAME_KEY, null);

        type = (Spinner) findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.type, R.layout.support_simple_spinner_dropdown_item);
        type.setAdapter(adapter);

        db = new DBHelper(UpdateProfile.this);

        weight = findViewById(R.id.weight);
        height = findViewById(R.id.height);
        update = findViewById(R.id.update);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String we= weight.getText().toString();
                String he = height.getText().toString();

                Integer ages = db.getAge(username);
                String gends =db.getGender(username);

                Double berat = Double.parseDouble(String.valueOf(we));
                Double tinggi = Double.parseDouble(String.valueOf(he));
                String types = type.getSelectedItem().toString();
                Double cal = calcCaloriesNeeded(ages,gends,tinggi,berat,types);
                Double calo = Double.parseDouble(String.valueOf(cal));

                Double bmiNew=0.0;
                bmiNew= berat/ (tinggi * tinggi);
                bmiStatus = calcBMI(bmiNew);


                boolean profileUpdate=db.profileUpdate(username,berat,tinggi,bmiStatus,types,calo);

                if (profileUpdate ==true){
                    Toast.makeText(UpdateProfile.this, "Succesfully Updated",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(UpdateProfile.this, mainNav.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(UpdateProfile.this, "Unsuccesfully",Toast.LENGTH_SHORT).show();
            }
        });


    }

    private Double calcCaloriesNeeded(Integer ages, String gend, Double heights, Double weights, String types) {
        Double cal=0.0;

        if(gend.equals("Male"))
        {
            if(types.equals("Tidak Aktif/Sedentary"))
            {
                cal= 864-9.27 * ages + 1.00 * 14.2 * weights + 503.0 * heights;
            }
            else if(types.equals("Kurang Aktif/Low active"))
            {
                cal= 864-9.27 * ages + 1.14*14.2 * weights + 503.0 * heights;
            }
            else if(types.equals("Aktif/Active"))
            {
                cal= 864-9.27 * ages + 1.27*14.2 * weights + 503.0 * heights;
            }
            else
            {
                cal= 864-9.27 * ages + 1.54*14.2 * weights + 503.0 * heights;
            }
        }
        if(gend.equals("Female"))
        {
            if(types.equals("Tidak Aktif/Sedentary"))
            {
                cal= 387-7.31 * ages + 1.00 * 14.2 * weights + 503.0 * heights;
            }
            else if(types.equals("Kurang Aktif/Low active"))
            {
                cal= 387-7.31 * ages + 1.14*14.2 * weights + 503.0 * heights;
            }
            else if(types.equals("Aktif/Active"))
            {
                cal= 387-7.31 * ages + 1.27*14.2 * weights + 503.0 * heights;
            }
            else
            {
                cal= 387-7.31 * ages + 1.54*14.2 * weights + 503.0 * heights;
            }

        }

        return cal;

    }

    private String calcBMI(Double bmis) {


        if(bmis < 18.5)
            bmiStatus = "Underweight";
        else if(bmis < 25)
            bmiStatus = "Normal";
        else if(bmis < 30)
            bmiStatus="Overweight";
        else
            bmiStatus="Obese";

        return bmiStatus;
    }

    public void ClickMenu(View view){
        //open drawer
        mainNav.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //close drawer
        mainNav.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view){
        //Redirect activity to home
        mainNav.redirectActivity(this,mainNav.class);

    }
    public void ClickMeal(View view){
        //redirect activity to meal time
        mainNav.redirectActivity(this,Mealtime.class);

    }

    public void ClickFood(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Food.class);


    }
    public void ClickReport(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Report.class);

    }
    public void ClickSetting(View view){
        //Redirect activity to food
        mainNav.redirectActivity(this,Setting.class);


    }
    public void ClickLogout(View view){
        //Redirect activity to food
        mainNav.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //close drawer
        mainNav.closeDrawer(drawerLayout);
    }
}