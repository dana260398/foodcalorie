package com.javacodegeeks.foodcalorieintake;

public class ReportModelClass {
    Integer id;
    String username, foodid, date,quantity,calorie;

    public ReportModelClass(String username, String foodid, String date, String quantity, String calorie) {
        this.username = username;
        this.foodid = foodid;
        this.date = date;
        this.quantity = quantity;
        this.calorie = calorie;
    }

    public ReportModelClass(Integer id, String username, String foodid, String date, String quantity, String calorie) {
        this.id = id;
        this.username = username;
        this.foodid = foodid;
        this.date = date;
        this.quantity = quantity;
        this.calorie = calorie;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFoodid() {
        return foodid;
    }

    public void setFoodid(String foodid) {
        this.foodid = foodid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getCalorie() {
        return calorie;
    }

    public void setCalorie(String calorie) {
        this.calorie = calorie;
    }
}
