package com.javacodegeeks.foodcalorieintake;

public class FoodModel {
    private int id, calories;
    private String name,size, weight;


    public FoodModel(Integer id, Integer calories, String name, String size, String weight) {
        this.id = id;
        this.calories = calories;
        this.name = name;
        this.size = size;
        this.weight = weight;
    }

    public FoodModel() {
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setCalories(Integer calories) {
        this.calories = calories;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public Integer getId() {
        return id;
    }

    public Integer getCalories() {
        return calories;
    }

    public String getName() {
        return name;
    }

    public String getSize() {
        return size;
    }

    public String getWeight() {
        return weight;
    }
}
